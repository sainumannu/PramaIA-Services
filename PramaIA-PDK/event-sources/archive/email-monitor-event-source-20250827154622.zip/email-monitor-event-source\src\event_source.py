import asyncio
import imaplib
import poplib
import email
import email.utils
import logging
import os
import re
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import sys
import json
import hashlib
from pathlib import Path

# Aggiungi il path del PDK per importare le utility
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'src'))

try:
    from core.event_source_base import BaseEventSourceProcessor
except ImportError:
    # Fallback per testing locale
    class BaseEventSourceProcessor:
        def __init__(self):
            self.logger = logging.getLogger(__name__)
        
        async def emit_event(self, event_type, data):
            logging.getLogger(__name__).info(f"[EVENT] {event_type}: {json.dumps(data, indent=2)}")
        
        def log_info(self, msg): logging.getLogger(__name__).info(msg)
        def log_warning(self, msg): logging.getLogger(__name__).warning(msg)
        def log_error(self, msg): logging.getLogger(__name__).error(msg)
        def log_debug(self, msg): logging.getLogger(__name__).debug(msg)

    # Adapter logger: prefer local wrapper 'logger', then pramaialog client, otherwise std logging
    try:
        from .logger import debug, info, warning, error, flush, close
    except Exception:
        try:
            from pramaialog import PramaIALogger

            _pramaialogger = PramaIALogger()

            def debug(msg, **kwargs):
                _pramaialogger.debug(msg, **kwargs)

            def info(msg, **kwargs):
                _pramaialogger.info(msg, **kwargs)

            def warning(msg, **kwargs):
                _pramaialogger.warning(msg, **kwargs)

            def error(msg, **kwargs):
                _pramaialogger.error(msg, **kwargs)

            def flush():
                try:
                    _pramaialogger.flush()
                except Exception:
                    pass

            def close():
                try:
                    _pramaialogger.close()
                except Exception:
                    pass

        except Exception:
            import logging as _std_logging

            def debug(msg, **kwargs):
                _std_logging.getLogger(__name__).debug(msg)

            def info(msg, **kwargs):
                _std_logging.getLogger(__name__).info(msg)

            def warning(msg, **kwargs):
                _std_logging.getLogger(__name__).warning(msg)

            def error(msg, **kwargs):
                _std_logging.getLogger(__name__).error(msg)

            def flush():
                return

            def close():
                return

class EmailMonitorEventSource(BaseEventSourceProcessor):
    def __init__(self):
        super().__init__()
        self.config = {}
        self.running = False
        self.monitoring_task = None
        self.processed_emails = set()  # Set di email ID già processate
        self.failed_emails = {}  # Dict di email fallite con retry count
        
    async def initialize(self, config: Dict[str, Any]) -> bool:
        """Inizializza l'event source con la configurazione"""
        try:
            self.config = config
            
            # Verifica configurazione connessione
            conn_config = config.get('connection', {})
            if not all(key in conn_config for key in ['server', 'username', 'password']):
                self.log_error("Configurazione connessione incompleta")
                return False
            
            # Crea directory per allegati se necessaria
            att_config = config.get('attachments', {})
            if att_config.get('extract_attachments', True):
                save_path = att_config.get('save_path', './attachments')
                Path(save_path).mkdir(parents=True, exist_ok=True)
                self.log_info(f"Directory allegati: {save_path}")
            
            self.log_info("Email Monitor Event Source inizializzato correttamente")
            return True
            
        except Exception as e:
            self.log_error(f"Errore durante l'inizializzazione: {e}")
            return False
    
    async def start(self) -> bool:
        """Avvia il monitoraggio email"""
        try:
            if self.running:
                return True
            
            self.running = True
            self.monitoring_task = asyncio.create_task(self._monitoring_loop())
            
            conn_config = self.config.get('connection', {})
            server = conn_config.get('server')
            protocol = conn_config.get('protocol', 'IMAP')
            
            self.log_info(f"Email monitoring avviato - {protocol} su {server}")
            return True
            
        except Exception as e:
            self.log_error(f"Errore durante l'avvio: {e}")
            return False
    
    async def stop(self) -> bool:
        """Ferma il monitoraggio email"""
        try:
            self.running = False
            
            if self.monitoring_task:
                self.monitoring_task.cancel()
                try:
                    await self.monitoring_task
                except asyncio.CancelledError:
                    pass
            
            self.log_info("Email monitoring fermato")
            return True
            
        except Exception as e:
            self.log_error(f"Errore durante lo stop: {e}")
            return False
    
    async def cleanup(self):
        """Pulizia risorse"""
        await self.stop()
    
    async def _monitoring_loop(self):
        """Loop principale di monitoraggio email"""
        polling_interval = self.config.get('polling_interval', 60)
        
        try:
            while self.running:
                try:
                    await self._check_emails()
                except Exception as e:
                    self.log_error(f"Errore durante il controllo email: {e}")
                    await self._emit_processing_error("email_check", str(e))
                
                # Attendi il prossimo ciclo
                await asyncio.sleep(polling_interval)
                
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.log_error(f"Errore critico nel loop di monitoraggio: {e}")
    
    async def _check_emails(self):
        """Controlla nuove email sui server configurati"""
        conn_config = self.config.get('connection', {})
        protocol = conn_config.get('protocol', 'IMAP')
        
        if protocol.upper() == 'IMAP':
            await self._check_imap_emails()
        elif protocol.upper() == 'POP3':
            await self._check_pop3_emails()
        else:
            self.log_error(f"Protocollo non supportato: {protocol}")
    
    async def _check_imap_emails(self):
        """Controlla email via IMAP"""
        conn_config = self.config.get('connection', {})
        server = conn_config.get('server')
        port = conn_config.get('port', 993)
        use_ssl = conn_config.get('use_ssl', True)
        username = conn_config.get('username')
        password = conn_config.get('password')
        
        try:
            # Connessione IMAP
            if use_ssl:
                mail = imaplib.IMAP4_SSL(server, port)
            else:
                mail = imaplib.IMAP4(server, port)
            
            mail.login(username, password)
            
            # Controlla ogni cartella configurata
            folders = self.config.get('folders', ['INBOX'])
            for folder in folders:
                try:
                    await self._process_imap_folder(mail, folder)
                except Exception as e:
                    self.log_error(f"Errore processando cartella {folder}: {e}")
            
            mail.logout()
            
        except Exception as e:
            self.log_error(f"Errore connessione IMAP: {e}")
            await self._emit_processing_error("imap_connection", str(e))
    
    async def _process_imap_folder(self, mail, folder: str):
        """Processa email in una cartella IMAP"""
        try:
            status, messages = mail.select(folder)
            if status != 'OK':
                self.log_warning(f"Impossibile selezionare cartella {folder}")
                return
            
            # Cerca email non lette o recenti
            search_criteria = self._build_search_criteria()
            status, message_ids = mail.search(None, search_criteria)
            
            if status != 'OK':
                return
            
            message_list = message_ids[0].split()
            max_emails = self.config.get('processing', {}).get('max_emails_per_check', 50)
            
            # Limita il numero di email per ciclo
            if len(message_list) > max_emails:
                message_list = message_list[-max_emails:]  # Prende le più recenti
            
            self.log_debug(f"Trovate {len(message_list)} email in {folder}")
            
            # Processa email in gruppi per concorrenza
            concurrent_limit = self.config.get('processing', {}).get('concurrent_processing', 3)
            
            for i in range(0, len(message_list), concurrent_limit):
                batch = message_list[i:i + concurrent_limit]
                tasks = []
                
                for msg_id in batch:
                    task = self._process_single_email(mail, msg_id.decode(), folder)
                    tasks.append(task)
                
                # Esegui batch in parallelo
                await asyncio.gather(*tasks, return_exceptions=True)
                
        except Exception as e:
            self.log_error(f"Errore processando cartella IMAP {folder}: {e}")
    
    def _build_search_criteria(self) -> str:
        """Costruisce criteri di ricerca IMAP basati sui filtri"""
        criteria = []
        
        filters = self.config.get('filters', {})
        
        # Filtro età
        max_age_days = filters.get('max_age_days', 7)
        if max_age_days > 0:
            since_date = (datetime.now() - timedelta(days=max_age_days)).strftime('%d-%b-%Y')
            criteria.append(f'SINCE {since_date}')
        
        # Altri criteri potrebbero essere aggiunti qui
        
        if not criteria:
            criteria.append('UNSEEN')  # Default: solo non lette
        
        return ' '.join(criteria)
    
    async def _process_single_email(self, mail, msg_id: str, folder: str):
        """Processa una singola email"""
        try:
            # Evita di processare email già elaborate
            email_key = f"{folder}:{msg_id}"
            if email_key in self.processed_emails:
                return
            
            # Scarica email
            status, msg_data = mail.fetch(msg_id, '(RFC822)')
            if status != 'OK':
                return
            
            # Parsing email
            raw_email = msg_data[0][1]
            email_message = email.message_from_bytes(raw_email)
            
            # Verifica filtri
            if not await self._passes_filters(email_message):
                self.processed_emails.add(email_key)
                return
            
            # Estrai dati email
            email_data = await self._extract_email_data(email_message, msg_id, folder)
            
            # Processa allegati se configurato
            attachments_data = []
            att_config = self.config.get('attachments', {})
            if att_config.get('extract_attachments', True):
                attachments_data = await self._extract_attachments(email_message, email_data['email_id'])
            
            email_data['attachments'] = attachments_data
            
            # Emetti evento
            await self.emit_event("email_received", email_data)
            
            # Marca come processata
            self.processed_emails.add(email_key)
            
            # Post-processing (marca come letta, sposta, etc.)
            await self._post_process_email(mail, msg_id, email_message)
            
            self.log_info(f"Email processata: {email_data['subject'][:50]}...")
            
        except Exception as e:
            self.log_error(f"Errore processando email {msg_id}: {e}")
            await self._emit_processing_error("email_processing", str(e), msg_id)
    
    async def _passes_filters(self, email_message) -> bool:
        """Verifica se l'email passa i filtri configurati"""
        filters = self.config.get('filters', {})
        
        try:
            # Filtro mittente whitelist
            sender_whitelist = filters.get('sender_whitelist', [])
            if sender_whitelist:
                sender = email_message.get('From', '').lower()
                if not any(allowed.lower() in sender for allowed in sender_whitelist):
                    return False
            
            # Filtro mittente blacklist
            sender_blacklist = filters.get('sender_blacklist', [])
            if sender_blacklist:
                sender = email_message.get('From', '').lower()
                if any(blocked.lower() in sender for blocked in sender_blacklist):
                    return False
            
            # Filtro parole chiave oggetto
            subject_keywords = filters.get('subject_keywords', [])
            if subject_keywords:
                subject = email_message.get('Subject', '').lower()
                if not any(keyword.lower() in subject for keyword in subject_keywords):
                    return False
            
            # Filtro regex oggetto
            subject_regex = filters.get('subject_regex', '')
            if subject_regex:
                subject = email_message.get('Subject', '')
                if not re.search(subject_regex, subject):
                    return False
            
            # Filtro allegati
            has_attachments_filter = filters.get('has_attachments', False)
            if has_attachments_filter:
                has_attachments = any(part.get_content_disposition() == 'attachment' 
                                    for part in email_message.walk())
                if not has_attachments:
                    return False
            
            # Filtro età minima
            min_age_minutes = filters.get('min_age_minutes', 2)
            if min_age_minutes > 0:
                date_str = email_message.get('Date', '')
                if date_str:
                    email_date = email.utils.parsedate_to_datetime(date_str)
                    age_minutes = (datetime.now(email_date.tzinfo) - email_date).total_seconds() / 60
                    if age_minutes < min_age_minutes:
                        return False
            
            return True
            
        except Exception as e:
            self.log_warning(f"Errore nella verifica filtri: {e}")
            return False
    
    async def _extract_email_data(self, email_message, msg_id: str, folder: str) -> Dict[str, Any]:
        """Estrae dati strutturati dall'email"""
        # Genera ID univoco
        email_id = str(uuid.uuid4())
        
        # Estrai header principali
        subject = email_message.get('Subject', '')
        message_id = email_message.get('Message-ID', '')
        sender_raw = email_message.get('From', '')
        date_str = email_message.get('Date', '')
        
        # Parsing mittente
        sender_name, sender_email = email.utils.parseaddr(sender_raw)
        sender = {
            "name": sender_name,
            "email": sender_email
        }
        
        # Parsing destinatari
        recipients = {
            "to": self._parse_addresses(email_message.get('To', '')),
            "cc": self._parse_addresses(email_message.get('Cc', '')),
            "bcc": self._parse_addresses(email_message.get('Bcc', ''))
        }
        
        # Estrai corpo email
        body_text, body_html = self._extract_body(email_message)
        
        # Timestamp
        received_at = email.utils.parsedate_to_datetime(date_str).isoformat() if date_str else ""
        processed_at = datetime.utcnow().isoformat() + "Z"
        
        # Headers importanti
        headers = {
            "message_id": message_id,
            "date": date_str,
            "reply_to": email_message.get('Reply-To', ''),
            "in_reply_to": email_message.get('In-Reply-To', ''),
            "references": email_message.get('References', ''),
            "return_path": email_message.get('Return-Path', '')
        }
        
        # Tags automatici (potrebbero essere estesi)
        tags = self._generate_auto_tags(email_message)
        
        return {
            "email_id": email_id,
            "message_id": message_id,
            "subject": subject,
            "sender": sender,
            "recipients": recipients,
            "body_text": body_text,
            "body_html": body_html,
            "attachments": [],  # Sarà popolato separatamente
            "headers": headers,
            "received_at": received_at,
            "processed_at": processed_at,
            "folder": folder,
            "tags": tags
        }
    
    def _parse_addresses(self, addresses_str: str) -> List[Dict[str, str]]:
        """Parsing lista indirizzi email"""
        if not addresses_str:
            return []
        
        addresses = []
        for name, email_addr in email.utils.getaddresses([addresses_str]):
            addresses.append({
                "name": name,
                "email": email_addr
            })
        return addresses
    
    def _extract_body(self, email_message) -> Tuple[str, str]:
        """Estrae corpo testuale e HTML dell'email"""
        body_text = ""
        body_html = ""
        
        try:
            if email_message.is_multipart():
                for part in email_message.walk():
                    content_type = part.get_content_type()
                    content_disposition = part.get_content_disposition()
                    
                    if content_disposition != 'attachment':
                        if content_type == "text/plain":
                            charset = part.get_content_charset() or 'utf-8'
                            body_text += part.get_payload(decode=True).decode(charset, errors='ignore')
                        elif content_type == "text/html":
                            charset = part.get_content_charset() or 'utf-8'
                            body_html += part.get_payload(decode=True).decode(charset, errors='ignore')
            else:
                content_type = email_message.get_content_type()
                charset = email_message.get_content_charset() or 'utf-8'
                payload = email_message.get_payload(decode=True).decode(charset, errors='ignore')
                
                if content_type == "text/plain":
                    body_text = payload
                elif content_type == "text/html":
                    body_html = payload
                else:
                    body_text = payload  # Fallback
                    
        except Exception as e:
            self.log_warning(f"Errore estrazione corpo email: {e}")
        
        return body_text, body_html
    
    def _generate_auto_tags(self, email_message) -> List[str]:
        """Genera tag automatici basati sul contenuto email"""
        tags = []
        
        # Tag basati su allegati
        has_attachments = any(part.get_content_disposition() == 'attachment' 
                            for part in email_message.walk())
        if has_attachments:
            tags.append("has_attachments")
        
        # Tag basati su oggetto
        subject = email_message.get('Subject', '').lower()
        if 'urgent' in subject or 'priority' in subject:
            tags.append("urgent")
        if 'invoice' in subject or 'bill' in subject:
            tags.append("invoice")
        if 'report' in subject:
            tags.append("report")
        
        return tags
    
    async def _extract_attachments(self, email_message, email_id: str) -> List[Dict[str, Any]]:
        """Estrae e salva allegati email"""
        attachments = []
        att_config = self.config.get('attachments', {})
        save_path = Path(att_config.get('save_path', './attachments'))
        allowed_extensions = att_config.get('allowed_extensions', [])
        max_size_mb = att_config.get('max_size_mb', 50)
        max_size_bytes = max_size_mb * 1024 * 1024
        
        try:
            for part in email_message.walk():
                if part.get_content_disposition() == 'attachment':
                    filename = part.get_filename()
                    if not filename:
                        continue
                    
                    # Verifica estensione se configurata
                    if allowed_extensions:
                        file_ext = Path(filename).suffix.lower()
                        if file_ext not in allowed_extensions:
                            self.log_debug(f"Allegato ignorato per estensione: {filename}")
                            continue
                    
                    # Ottieni payload
                    payload = part.get_payload(decode=True)
                    if not payload:
                        continue
                    
                    # Verifica dimensione
                    if len(payload) > max_size_bytes:
                        self.log_warning(f"Allegato troppo grande ignorato: {filename} ({len(payload)} bytes)")
                        continue
                    
                    # Genera nome file sicuro
                    attachment_id = str(uuid.uuid4())
                    safe_filename = self._sanitize_filename(filename)
                    file_path = save_path / f"{attachment_id}_{safe_filename}"
                    
                    # Salva file
                    with open(file_path, 'wb') as f:
                        f.write(payload)
                    
                    # Metadati allegato
                    attachment_data = {
                        "attachment_id": attachment_id,
                        "email_id": email_id,
                        "filename": filename,
                        "file_path": str(file_path),
                        "file_size": len(payload),
                        "mime_type": part.get_content_type(),
                        "file_extension": Path(filename).suffix.lower(),
                        "extracted_at": datetime.utcnow().isoformat() + "Z"
                    }
                    
                    attachments.append(attachment_data)
                    
                    # Emetti evento separato per allegato
                    await self.emit_event("attachment_extracted", attachment_data)
                    
                    self.log_info(f"Allegato estratto: {filename} ({len(payload)} bytes)")
                    
        except Exception as e:
            self.log_error(f"Errore estrazione allegati: {e}")
        
        return attachments
    
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitizza nome file per salvataggio sicuro"""
        # Rimuovi caratteri pericolosi
        safe_chars = re.sub(r'[<>:"/\\|?*]', '_', filename)
        # Limita lunghezza
        if len(safe_chars) > 100:
            name, ext = os.path.splitext(safe_chars)
            safe_chars = name[:95] + ext
        return safe_chars
    
    async def _post_process_email(self, mail, msg_id: str, email_message):
        """Post-processing dell'email (marca come letta, sposta, etc.)"""
        try:
            processing_config = self.config.get('processing', {})
            
            # Marca come letta
            if processing_config.get('mark_as_read', False):
                mail.store(msg_id, '+FLAGS', '\\Seen')
            
            # Sposta in cartella processate
            if processing_config.get('move_processed', False):
                processed_folder = processing_config.get('processed_folder', 'Processed')
                try:
                    mail.move(msg_id, processed_folder)
                    self.log_debug(f"Email spostata in {processed_folder}")
                except Exception as e:
                    self.log_warning(f"Impossibile spostare email: {e}")
                    
        except Exception as e:
            self.log_warning(f"Errore post-processing: {e}")
    
    async def _check_pop3_emails(self):
        """Controlla email via POP3 (implementazione semplificata)"""
        # POP3 è più limitato di IMAP, principalmente per download completo
        self.log_warning("Supporto POP3 non ancora implementato completamente")
        # TODO: Implementare POP3 se necessario
    
    async def _emit_processing_error(self, error_type: str, error_message: str, email_id: str = None):
        """Emetti evento per errore di processing"""
        error_data = {
            "error_id": str(uuid.uuid4()),
            "email_id": email_id,
            "error_type": error_type,
            "error_message": error_message,
            "error_at": datetime.utcnow().isoformat() + "Z",
            "retry_count": self.failed_emails.get(email_id, 0) if email_id else 0
        }
        
        await self.emit_event("email_processing_error", error_data)

# Entry point per testing
if __name__ == "__main__":
    async def main():
        # Configurazione di test (ATTENZIONE: non usare credenziali reali nei test)
        config = {
            "connection": {
                "protocol": "IMAP",
                "server": "imap.gmail.com", 
                "port": 993,
                "use_ssl": True,
                "username": "test@example.com",
                "password": "app_password_here"  # Usa App Password per Gmail
            },
            "folders": ["INBOX"],
            "polling_interval": 30,
            "filters": {
                "subject_keywords": ["test", "demo"],
                "min_age_minutes": 1,
                "max_age_days": 7
            },
            "attachments": {
                "extract_attachments": True,
                "save_path": "./test_attachments",
                "allowed_extensions": [".pdf", ".txt", ".jpg"],
                "max_size_mb": 10
            },
            "processing": {
                "mark_as_read": False,
                "max_emails_per_check": 10,
                "concurrent_processing": 2
            },
            "logging": {
                "log_email_content": False,
                "log_level": "INFO"
            }
        }
        
        email_monitor = EmailMonitorEventSource()
        
        try:
            logging.getLogger(__name__).warning("ATTENZIONE: Configura credenziali email reali prima del test!")
            logging.getLogger(__name__).info("Questo è solo un esempio di configurazione.")
            
            # await email_monitor.initialize(config)
            # await email_monitor.start()
            
            logging.getLogger(__name__).info("Email monitor configurato (non avviato per sicurezza)")
            logging.getLogger(__name__).info("Modifica le credenziali nel codice per testare")
            
        except KeyboardInterrupt:
            logging.getLogger(__name__).info("\nFermando monitor...")
        finally:
            await email_monitor.cleanup()
    
    asyncio.run(main())
