# Email Monitor Event Source

Event source per monitoraggio automatico di caselle email IMAP/POP3 con estrazione allegati e filtri avanzati.

## Caratteristiche

- **Protocolli supportati**: IMAP (completo), POP3 (base)
- **Autenticazione sicura** con supporto SSL/TLS
- **Filtri avanzati** per mittenti, oggetto, età, allegati
- **Estrazione allegati** automatica con validazione
- **Processing parallelo** per performance ottimali
- **Post-processing** configurabile (marca letta, sposta)
- **Retry logic** per email fallite
- **Logging dettagliato** per debugging

## Configurazione

### Connessione IMAP Base
```json
{
  "connection": {
    "protocol": "IMAP",
    "server": "imap.gmail.com",
    "port": 993,
    "use_ssl": true,
    "username": "user@gmail.com",
    "password": "app_password"
  },
  "folders": ["INBOX"],
  "polling_interval": 60
}
```

### Filtri Avanzati
```json
{
  "filters": {
    "sender_whitelist": ["trusted@company.com", "@partner.com"],
    "sender_blacklist": ["spam@evil.com"],
    "subject_keywords": ["invoice", "report", "urgent"],
    "subject_regex": "\\b(invoice|bill)\\s+#\\d+",
    "min_age_minutes": 2,
    "max_age_days": 7,
    "has_attachments": true
  }
}
```

### Gestione Allegati
```json
{
  "attachments": {
    "extract_attachments": true,
    "save_path": "./attachments",
    "allowed_extensions": [".pdf", ".doc", ".xlsx", ".jpg"],
    "max_size_mb": 50
  }
}
```

### Processing Avanzato
```json
{
  "processing": {
    "mark_as_read": true,
    "move_processed": true,
    "processed_folder": "PramaIA_Processed",
    "max_emails_per_check": 50,
    "concurrent_processing": 5
  },
  "retry": {
    "max_retries": 3,
    "retry_delay_seconds": 300
  }
}
```

## Eventi Generati

### email_received
Generato quando una nuova email passa i filtri.

**Output**:
- `email_id`: ID univoco generato
- `message_id`: Message-ID dell'email
- `subject`: Oggetto email
- `sender`: Informazioni mittente (nome, email)
- `recipients`: Destinatari (to, cc, bcc)
- `body_text`: Corpo in testo semplice
- `body_html`: Corpo HTML (se disponibile)
- `attachments`: Lista allegati con metadati
- `headers`: Headers email importanti
- `received_at`: Timestamp ricezione server
- `processed_at`: Timestamp elaborazione
- `folder`: Cartella email
- `tags`: Tag automatici assegnati

### attachment_extracted
Generato per ogni allegato estratto.

**Output**:
- `attachment_id`: ID univoco allegato
- `email_id`: ID email parent
- `filename`: Nome file originale
- `file_path`: Percorso locale allegato
- `file_size`: Dimensione in bytes
- `mime_type`: Tipo MIME
- `file_extension`: Estensione file
- `extracted_at`: Timestamp estrazione

### email_processing_error
Generato per errori durante l'elaborazione.

**Output**:
- `error_id`: ID univoco errore
- `email_id`: ID email (se disponibile)
- `error_type`: Tipo errore
- `error_message`: Messaggio dettagliato
- `error_at`: Timestamp errore
- `retry_count`: Numero tentativi

## Provider Email Supportati

### Gmail
```json
{
  "connection": {
    "server": "imap.gmail.com",
    "port": 993,
    "use_ssl": true,
    "username": "user@gmail.com",
    "password": "app_password"
  }
}
```

**Note**: Richiede App Password, non password account.

### Outlook/Hotmail
```json
{
  "connection": {
    "server": "outlook.office365.com", 
    "port": 993,
    "use_ssl": true,
    "username": "user@outlook.com",
    "password": "account_password"
  }
}
```

### Exchange Server
```json
{
  "connection": {
    "server": "mail.company.com",
    "port": 993,
    "use_ssl": true,
    "username": "domain\\username",
    "password": "domain_password"
  }
}
```

## Testing

### Configurazione Test
```json
{
  "connection": {
    "server": "imap.ethereal.email",
    "port": 993,
    "use_ssl": true,
    "username": "test_user",
    "password": "test_pass"
  },
  "folders": ["INBOX"],
  "polling_interval": 30,
  "filters": {
    "max_age_days": 1
  },
  "attachments": {
    "extract_attachments": true,
    "save_path": "./test_attachments"
  }
}
```

### Avvio Test
```bash
cd email-monitor-event-source
pip install -r requirements.txt
# Modifica credenziali in event_source.py
python src/event_source.py
```

## Use Cases

1. **Invoice Processing**: Monitora email fatture, estrae PDF, triggera workflow contabilità
2. **Document Workflow**: Processa documenti inviati via email automaticamente
3. **Customer Support**: Monitora email supporto, categorizza e assegna ticket
4. **Report Distribution**: Intercetta report periodici, li elabora e distribuisce
5. **Compliance Monitoring**: Monitora comunicazioni per compliance e audit

## Sicurezza

### Best Practices
- Usa sempre SSL/TLS per connessioni
- Utilizza App Password invece delle password account
- Limita accesso cartelle sensibili
- Configura whitelist mittenti per dati critici
- Non loggare contenuti email sensibili
- Crittografa credenziali nel deployment

### Gestione Credenziali
```json
{
  "connection": {
    "username": "${EMAIL_USERNAME}",
    "password": "${EMAIL_PASSWORD}"
  }
}
```

Usa variabili d'ambiente per credenziali in produzione.

## Troubleshooting

### Errori Comuni

#### Errore Autenticazione
- Verifica credenziali
- Controlla se richiede App Password
- Verifica impostazioni sicurezza account

#### Timeout Connessione
- Controlla firewall
- Verifica porta e SSL
- Aumenta timeout

#### Allegati non estratti
- Verifica permessi directory
- Controlla filtri estensioni
- Verifica limite dimensioni

### Debug
```json
{
  "logging": {
    "log_email_content": true,
    "log_level": "DEBUG"
  }
}
```

**ATTENZIONE**: `log_email_content: true` può esporre dati sensibili nei log.
