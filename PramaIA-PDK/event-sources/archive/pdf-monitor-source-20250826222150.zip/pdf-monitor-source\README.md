# PDF Monitor Event Source

## Panoramica

Questa è una sorgente di eventi per il sistema PramaIA che monitora cartelle specifiche per rilevare cambiamenti nei file PDF (creazione, modifica, eliminazione).

## Installazione

1. Assicurati di avere Python 3.8+ installato
2. Installa le dipendenze:
   ```bash
   pip install watchdog requests
   ```

## Configurazione

La configurazione viene effettuata attraverso l'interfaccia del PDK, con i seguenti parametri:

| Parametro | Descrizione | Default |
|-----------|-------------|---------|
| monitor_path | Percorso assoluto della cartella da monitorare | - |
| recursive | Se monitorare anche le sottocartelle | true |
| file_extensions | Lista delle estensioni file da monitorare | [".pdf"] |
| ignore_hidden | Se ignorare i file che iniziano con punto | true |
| debounce_time | Tempo di attesa (sec) prima di processare un evento per evitare duplicati | 2 |
| max_file_size | Dimensione massima dei file (MB) da processare (0 = nessun limite) | 100 |

## Eventi

Questa sorgente genera i seguenti tipi di eventi:

### pdf_file_added

Generato quando un nuovo file PDF viene aggiunto alla cartella monitorata.

**Output:**
- `file_path`: Percorso assoluto del file PDF
- `file_name`: Nome del file PDF
- `file_size`: Dimensione del file in bytes
- `timestamp`: Timestamp del rilevamento
- `watched_folder`: Cartella monitorata

### pdf_file_modified

Generato quando un file PDF esistente viene modificato.

**Output:**
- `file_path`: Percorso assoluto del file PDF
- `file_name`: Nome del file PDF
- `file_size`: Nuova dimensione del file in bytes
- `previous_size`: Dimensione precedente del file (se disponibile)
- `timestamp`: Timestamp del rilevamento
- `watched_folder`: Cartella monitorata

### pdf_file_deleted

Generato quando un file PDF viene eliminato.

**Output:**
- `file_path`: Percorso assoluto del file PDF eliminato
- `file_name`: Nome del file PDF
- `timestamp`: Timestamp del rilevamento
- `watched_folder`: Cartella monitorata

### any_change

Generato per qualsiasi tipo di cambiamento (aggiunta, modifica, eliminazione).

**Output:**
- `file_path`: Percorso assoluto del file PDF
- `file_name`: Nome del file PDF
- `file_size`: Dimensione del file in bytes (null per file eliminati)
- `timestamp`: Timestamp del rilevamento
- `change_type`: Tipo di cambiamento ('created', 'modified', 'deleted')
- `watched_folder`: Cartella monitorata

## Utilizzo con PDK

Questa sorgente eventi è integrata nel sistema PDK di PramaIA e può essere utilizzata per avviare workflow quando vengono rilevati nuovi file PDF o modifiche a file esistenti.

## Note sulla sicurezza

- Assicurarsi che il percorso monitorato non contenga dati sensibili non autorizzati
- Utilizzare il parametro `max_file_size` per evitare di processare file troppo grandi
- I percorsi completi dei file vengono inclusi negli eventi, quindi prestare attenzione a chi ha accesso agli eventi generati
