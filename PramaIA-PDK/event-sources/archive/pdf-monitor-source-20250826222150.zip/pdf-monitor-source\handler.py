"""
PDF Monitor Event Source Handler
Gestisce il monitoraggio delle cartelle PDF e l'invio di eventi al server PramaIA
"""
import os
import time
import json
import requests
import logging
from pathlib import Path
from typing import Dict, List, Optional
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent

# Impostazione logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("pdf-monitor-source")

class PDFMonitorHandler(FileSystemEventHandler):
    """Handler per eventi del file system relativi ai PDF"""
    
    def __init__(self, config: Dict, event_emitter):
        self.config = config
        self.event_emitter = event_emitter
        self.extensions = config.get('file_extensions', ['.pdf'])
        self.debounce_time = config.get('debounce_time', 2)  # In seconds
        self.max_file_size = config.get('max_file_size', 0) * 1024 * 1024  # Convert MB to bytes
        self.ignore_hidden = config.get('ignore_hidden', True)
        self.pending_events = {}  # For debouncing
        
    def _is_pdf_file(self, file_path: str) -> bool:
        """Controlla se il file è un PDF basandosi sull'estensione"""
        if not file_path:
            return False
            
        # Check if hidden file (starts with .)
        if self.ignore_hidden and os.path.basename(file_path).startswith('.'):
            return False
            
        return any(file_path.lower().endswith(ext.lower()) for ext in self.extensions)
    
    def _is_file_too_large(self, file_path: str) -> bool:
        """Controlla se il file supera la dimensione massima consentita"""
        if self.max_file_size == 0:  # 0 = nessun limite
            return False
        
        try:
            file_size = os.path.getsize(file_path)
            return file_size > self.max_file_size
        except OSError:
            return True  # Se non riusciamo a leggere la dimensione, consideriamo il file troppo grande
    
    def _emit_event(self, event_type: str, file_path: str, extra_data: Optional[Dict] = None):
        """Emette un evento al sistema PDK"""
        try:
            file_path_obj = Path(file_path)
            
            # Base event data
            event_data = {
                "file_path": str(file_path_obj),
                "file_name": file_path_obj.name,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "watched_folder": self.config.get('monitor_path', '')
            }
            
            # Add extra data if provided
            if extra_data:
                event_data.update(extra_data)
                
            # Emit event
            logger.info(f"Emitting {event_type} event for {file_path}")
            self.event_emitter.emit(event_type, event_data)
            
        except Exception as e:
            logger.error(f"Error emitting event: {e}")
    
    def on_created(self, event: FileSystemEvent):
        """Gestisce eventi di creazione file"""
        if not event.is_directory and self._is_pdf_file(event.src_path):
            file_path = event.src_path
            
            # Debounce to avoid duplicate events (file is sometimes detected multiple times)
            self.pending_events[file_path] = {
                'type': 'created',
                'timestamp': time.time(),
                'processed': False
            }
            
            # Schedule processing after debounce time
            self._schedule_delayed_processing(file_path)
    
    def on_modified(self, event: FileSystemEvent):
        """Gestisce eventi di modifica file"""
        if not event.is_directory and self._is_pdf_file(event.src_path):
            file_path = event.src_path
            
            # Get previous size if we have it
            previous_size = None
            if file_path in self.pending_events and self.pending_events[file_path]['type'] in ['created', 'modified']:
                try:
                    previous_size = self.pending_events[file_path].get('size')
                except:
                    pass
            
            # Debounce
            self.pending_events[file_path] = {
                'type': 'modified',
                'timestamp': time.time(),
                'processed': False,
                'previous_size': previous_size
            }
            
            # Try to get current size
            try:
                current_size = os.path.getsize(file_path)
                self.pending_events[file_path]['size'] = current_size
            except:
                pass
                
            # Schedule processing
            self._schedule_delayed_processing(file_path)
    
    def on_deleted(self, event: FileSystemEvent):
        """Gestisce eventi di eliminazione file"""
        if not event.is_directory and self._is_pdf_file(event.src_path):
            file_path = event.src_path
            
            # For deletion events, we don't need much debouncing as the file is gone
            self.pending_events[file_path] = {
                'type': 'deleted',
                'timestamp': time.time(),
                'processed': False
            }
            
            # Process delete events with less debounce time (half of regular time)
            time.sleep(self.debounce_time / 2)
            self._process_event(file_path)
    
    def _schedule_delayed_processing(self, file_path: str):
        """Schedula il processing dell'evento dopo il tempo di debounce"""
        def delayed_processing():
            time.sleep(self.debounce_time)
            self._process_event(file_path)
            
        # In a real implementation, we would use a proper scheduler or threading
        # For simplicity, we'll just use a small delay here
        import threading
        threading.Thread(target=delayed_processing).start()
    
    def _process_event(self, file_path: str):
        """Processa un evento in sospeso dopo il debounce"""
        if file_path not in self.pending_events:
            return
            
        event_info = self.pending_events[file_path]
        
        # Skip if already processed
        if event_info['processed']:
            return
            
        # Mark as processed
        event_info['processed'] = True
        
        event_type = event_info['type']
        
        # Handle different event types
        if event_type == 'created':
            # Skip if file is too large
            if self._is_file_too_large(file_path):
                logger.warning(f"Skipping large file: {file_path}")
                return
                
            # Get file size
            try:
                file_size = os.path.getsize(file_path)
                # Emit pdf_file_added event
                self._emit_event('pdf_file_added', file_path, {
                    'file_size': file_size
                })
                
                # Also emit any_change event
                self._emit_event('any_change', file_path, {
                    'file_size': file_size,
                    'change_type': 'created'
                })
            except Exception as e:
                logger.error(f"Error processing created event: {e}")
                
        elif event_type == 'modified':
            # Skip if file is too large
            if self._is_file_too_large(file_path):
                logger.warning(f"Skipping large file: {file_path}")
                return
                
            try:
                file_size = os.path.getsize(file_path)
                previous_size = event_info.get('previous_size')
                
                # Emit pdf_file_modified event
                self._emit_event('pdf_file_modified', file_path, {
                    'file_size': file_size,
                    'previous_size': previous_size
                })
                
                # Also emit any_change event
                self._emit_event('any_change', file_path, {
                    'file_size': file_size,
                    'change_type': 'modified'
                })
            except Exception as e:
                logger.error(f"Error processing modified event: {e}")
                
        elif event_type == 'deleted':
            try:
                # Emit pdf_file_deleted event
                self._emit_event('pdf_file_deleted', file_path)
                
                # Also emit any_change event
                self._emit_event('any_change', file_path, {
                    'file_size': None,
                    'change_type': 'deleted'
                })
            except Exception as e:
                logger.error(f"Error processing deleted event: {e}")
        
        # Clean up after some time
        def cleanup():
            time.sleep(60)  # Keep event info for 1 minute
            if file_path in self.pending_events:
                del self.pending_events[file_path]
                
        import threading
        threading.Thread(target=cleanup).start()


class PDFMonitorSource:
    """Main class for the PDF Monitor Event Source"""
    
    def __init__(self, config: Dict, event_emitter):
        self.config = config
        self.event_emitter = event_emitter
        self.observers = []
        
    def start(self):
        """Start monitoring folders"""
        monitor_path = self.config.get('monitor_path')
        
        if not monitor_path:
            logger.error("No monitor path specified in configuration")
            return
            
        recursive = self.config.get('recursive', True)
        
        logger.info(f"Starting PDF Monitor for path: {monitor_path}")
        
        # Create event handler
        event_handler = PDFMonitorHandler(self.config, self.event_emitter)
        
        # Set up observer
        observer = Observer()
        observer.schedule(event_handler, monitor_path, recursive=recursive)
        observer.start()
        
        # Store observer for later stopping
        self.observers.append(observer)
        
        logger.info(f"PDF Monitor started for {monitor_path}")
        
    def stop(self):
        """Stop all observers"""
        for observer in self.observers:
            observer.stop()
            
        # Wait for all observers to complete
        for observer in self.observers:
            observer.join()
            
        self.observers = []
        logger.info("PDF Monitor stopped")


# Entry point for PDK
def create_event_source(config, event_emitter):
    """Create a new instance of the PDF Monitor event source"""
    source = PDFMonitorSource(config, event_emitter)
    return source
